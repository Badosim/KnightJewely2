package com.example.myapplication;

public class Constants {
    public  static int screenWidth;
    public static int screenHeight;
    public static int cellWidth;
    public static float drawX;
    public static float drawY;}